# sdam-r
Statistics: Data analysis and modelling (r package)
